# Changelog

All notable changes to WP Minpaku Connector will be documented in this file.

## [1.1.0] - 2025-01-26

### Added
- **ドラッグ範囲選択**: カレンダーでマウス/タッチドラッグによる範囲選択が可能
  - クリックイン→ドラッグ→マウスアップ/指離しで範囲確定
  - 既存のクリックイン→クリックアウト方式も維持
  - マウス・タッチ両対応（mousedown/mousemove/mouseup, touchstart/touchmove/touchend）
- **見積API統一**: admin-ajax完全廃止、REST API一本化
  - 見積ボタンは `POST /wp-json/minpaku-connector/v1/quote` を使用
  - プロキシ経由でポータル `/wp-json/minpaku/v1/quote` をHMAC署名で呼び出し
  - 署名方式: X-MCS-Key / X-MCS-Ts / X-MCS-Body-Hash(SHA256) / X-MCS-Signature(HMAC-SHA256)
- **エラーハンドリング強化**: HTTPコード別の日本語エラーメッセージ
  - 401/403: 「認証に失敗しました」
  - 404: 「APIエンドポイントが見つかりません」
  - 422: ポータルからの具体的エラー（期間・在庫・定員エラー等）
  - 500: 「予期せぬエラーが発生しました」
- **UI/UX改善**:
  - ドラッグ操作中の視覚的フィードバック（`.mpc-dragging`, `.mpc-drag-start`）
  - エラートーストの改善（アニメーション付き、自動消去）
  - 見積テーブルのレスポンシブ対応

### Changed
- `calendar-interactions.js`: ドラッグ範囲選択機能を完全実装
- `quote.js`: admin-ajax依存を完全除去、REST API化
- `quote.css`: ドラッグ操作とエラー表示のスタイル追加

### Removed
- **admin-ajax呼び出し**: 見積機能からadmin-ajax呼び出しを完全除去

### Fixed
- 範囲選択確定時の .mpc-quote-selection サマリー表示
- タッチデバイスでのドラッグ操作の正確性
- エラー時のユーザビリティ向上

### Technical Details
- **Files Changed**:
  - `assets/js/calendar-interactions.js` (新規作成/更新)
  - `assets/js/quote.js` (REST API化)
  - `assets/css/quote.css` (スタイル拡張)
  - `includes/Routes/Quote.php` (確認済み)
- **API Endpoints**:
  - Connector: `POST /wp-json/minpaku-connector/v1/quote`
  - Portal Proxy: `POST /wp-json/minpaku/v1/quote` (HMAC署名付き)
- **Browser Support**: IE11+, Chrome, Firefox, Safari, Edge（モバイル含む）

### Migration Notes
- 既存のカレンダー設定は自動的に新しいドラッグ機能に対応
- admin-ajax依存のコードは自動的にREST APIに切り替わり
- CSS変更により既存のテーマとの互換性を確保

## [1.0.2] - Previous Release

### Previous features and fixes...