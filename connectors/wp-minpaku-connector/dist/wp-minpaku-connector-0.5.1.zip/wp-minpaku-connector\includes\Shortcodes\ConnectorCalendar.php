<?php
/**
 * Connector Calendar Shortcode - Portal Calendar Parity
 *
 * @package WP_Minpaku_Connector
 */

namespace MinpakuConnector\Shortcodes;

if (!defined('ABSPATH')) {
    exit;
}

class MPC_Shortcodes_ConnectorCalendar {

    public static function init() {
        add_shortcode('connector_calendar', [__CLASS__, 'render_calendar']);

        // Register AJAX handlers for modal functionality
        add_action('wp_ajax_connector_calendar_modal_content', [__CLASS__, 'ajax_modal_content']);
        add_action('wp_ajax_nopriv_connector_calendar_modal_content', [__CLASS__, 'ajax_modal_content']);
    }

    /**
     * Render calendar shortcode for connector side - Portal Parity
     */
    public static function render_calendar($atts) {
        $atts = shortcode_atts([
            'property_id' => '',
            'months' => 2,
            'show_prices' => 'true',
            'modal' => 'false'
        ], $atts, 'connector_calendar');

        // Auto-detect property ID if not provided
        $property_id = self::get_property_id($atts['property_id']);

        if (!$property_id) {
            return '<div class="mpc-error" style="background: #fef2f2; border: 1px solid #fca5a5; color: #b91c1c; padding: 12px; border-radius: 6px; margin: 16px 0;">' .
                   __('Property ID is required for calendar display. Please specify property_id="X" in the shortcode.', 'wp-minpaku-connector') .
                   '</div>';
        }

        $months = max(1, min(12, intval($atts['months'])));
        $show_prices = ($atts['show_prices'] === 'true');
        $is_modal = ($atts['modal'] === 'true');

        // Check API configuration
        if (!class_exists('MinpakuConnector\Client\MPC_Client_Api')) {
            return '<div class="mpc-error" style="background: #fef2f2; border: 1px solid #fca5a5; color: #b91c1c; padding: 12px; border-radius: 6px; margin: 16px 0;">' .
                   __('API client not available.', 'wp-minpaku-connector') .
                   '</div>';
        }

        $api = new \MinpakuConnector\Client\MPC_Client_Api();
        if (!$api->is_configured()) {
            return '<div class="mpc-error" style="background: #fef2f2; border: 1px solid #fca5a5; color: #b91c1c; padding: 12px; border-radius: 6px; margin: 16px 0;">' .
                   __('Portal connection not configured. Please check the connector settings.', 'wp-minpaku-connector') .
                   '</div>';
        }

        // Skip property validation for now - let the calendar display and handle errors gracefully
        $property_title = '';

        // Try to get property info but don't fail if not found
        $property_response = $api->get_property($property_id);
        if ($property_response['success']) {
            $property_title = $property_response['data']['title'] ?? '';
        }

        // モーダル表示の場合はボタンを返す
        if ($is_modal) {
            return self::render_modal_button($property_id, $months, $show_prices, $property_title);
        }

        $calendar_id = 'connector-calendar-' . uniqid();

        ob_start();
        ?>

        <div id="<?php echo esc_attr($calendar_id); ?>" class="mpc-calendar-container connector-calendar"
             data-property-id="<?php echo esc_attr($property_id); ?>"
             data-show-prices="<?php echo $show_prices ? '1' : '0'; ?>"
             data-months="<?php echo esc_attr($months); ?>">

            <?php for ($i = 0; $i < $months; $i++): ?>
                <?php
                $month_date = new \DateTime();
                $month_date->add(new \DateInterval('P' . $i . 'M'));
                $year = $month_date->format('Y');
                $month = $month_date->format('n');
                ?>

                <div class="mpc-calendar-month" data-year="<?php echo esc_attr($year); ?>" data-month="<?php echo esc_attr($month); ?>">
                    <h3 class="mpc-calendar-month-title">
                        <?php echo esc_html($month_date->format('Y年n月')); ?>
                    </h3>

                    <div class="mpc-calendar-grid">
                        <div class="mpc-calendar-header">
                            <div class="mpc-calendar-day-header"><?php _e('日', 'wp-minpaku-connector'); ?></div>
                            <div class="mpc-calendar-day-header"><?php _e('月', 'wp-minpaku-connector'); ?></div>
                            <div class="mpc-calendar-day-header"><?php _e('火', 'wp-minpaku-connector'); ?></div>
                            <div class="mpc-calendar-day-header"><?php _e('水', 'wp-minpaku-connector'); ?></div>
                            <div class="mpc-calendar-day-header"><?php _e('木', 'wp-minpaku-connector'); ?></div>
                            <div class="mpc-calendar-day-header"><?php _e('金', 'wp-minpaku-connector'); ?></div>
                            <div class="mpc-calendar-day-header"><?php _e('土', 'wp-minpaku-connector'); ?></div>
                        </div>

                        <?php echo self::generate_calendar_days($year, $month, $property_id, $show_prices, $api); ?>
                    </div>
                </div>
            <?php endfor; ?>
        </div>

        <!-- Connector Calendar CSS - Portal Parity Design -->
        <style>
        .connector-calendar {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
        }

        .connector-calendar .mpc-calendar-legend {
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .connector-calendar .mpc-calendar-legend h4 {
            margin: 0 0 16px 0;
            font-size: 16px;
            font-weight: 600;
            color: #2c3e50;
        }

        .connector-calendar .mpc-legend-items {
            display: flex;
            gap: 24px;
            flex-wrap: wrap;
        }

        .connector-calendar .mpc-legend-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .connector-calendar .mpc-legend-color {
            width: 20px;
            height: 20px;
            border-radius: 4px;
            border: 1px solid rgba(0,0,0,0.15);
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .connector-calendar .mpc-legend-label {
            font-size: 14px;
            color: #555;
            font-weight: 500;
        }

        .connector-calendar .mpc-calendar-container {
            max-width: 100%;
            margin: 0;
        }

        .connector-calendar .mpc-calendar-month {
            margin-bottom: 32px;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border: 1px solid #e5e7eb;
        }

        .connector-calendar .mpc-calendar-month-title {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            margin: 0;
            padding: 20px 24px;
            text-align: center;
            font-size: 20px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .connector-calendar .mpc-calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 0;
            background: #fafafa;
        }

        .connector-calendar .mpc-calendar-header {
            display: contents;
        }

        .connector-calendar .mpc-calendar-day-header {
            background: #f8fafc;
            color: #64748b;
            padding: 16px 8px;
            text-align: center;
            font-weight: 600;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 2px solid #e2e8f0;
            border-right: 1px solid #e2e8f0;
        }

        .connector-calendar .mpc-calendar-day-header:last-child {
            border-right: none;
        }

        .connector-calendar .mpc-calendar-week {
            display: contents;
        }

        .connector-calendar .mcs-day {
            position: relative;
            min-height: 90px;
            padding: 12px 8px 8px 8px;
            border-right: 1px solid #e2e8f0;
            border-bottom: 1px solid #e2e8f0;
            cursor: pointer;
            transition: all 0.2s ease;
            background: white;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            justify-content: space-between;
            overflow: hidden;
        }

        .connector-calendar .mcs-day:nth-child(7n) {
            border-right: none;
        }

        .connector-calendar .mcs-day:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            z-index: 2;
        }

        .connector-calendar .mcs-day--empty {
            background: #f8fafc !important;
            cursor: default;
            opacity: 0.5;
        }

        .connector-calendar .mcs-day--empty:hover {
            transform: none;
            box-shadow: none;
        }

        .connector-calendar .mcs-day--weekday {
            background: #f0fdf4 !important;
            border-left: 3px solid #22c55e;
        }

        .connector-calendar .mcs-day--sat {
            background: #eff6ff !important;
            border-left: 3px solid #3b82f6;
        }

        .connector-calendar .mcs-day--sun {
            background: #fef2f2 !important;
            border-left: 3px solid #ef4444;
        }

        .connector-calendar .mcs-day--full,
        .connector-calendar .mcs-day--blackout {
            background: #f1f5f9 !important;
            cursor: not-allowed !important;
            opacity: 0.6;
            border-left: 3px solid #64748b;
        }

        .connector-calendar .mcs-day--booked {
            cursor: pointer !important;
        }

        .connector-calendar .mcs-day--full:hover,
        .connector-calendar .mcs-day--blackout:hover {
            transform: none;
            box-shadow: none;
        }

        .connector-calendar .mcs-day--booked:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .connector-calendar .mcs-day--past {
            background: #f8fafc !important;
            color: #94a3b8;
            cursor: not-allowed;
            opacity: 0.5;
        }

        .connector-calendar .mcs-day--past:hover {
            transform: none;
            box-shadow: none;
        }

        .connector-calendar .mcs-day-number {
            font-weight: 700;
            font-size: 16px;
            line-height: 1.2;
            color: #1e293b;
            margin-bottom: auto;
        }

        .connector-calendar .mcs-day--past .mcs-day-number {
            color: #94a3b8;
        }

        .connector-calendar .mcs-day-price {
            align-self: stretch;
            margin-top: 8px;
            padding: 6px 8px;
            border-radius: 6px;
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            color: white;
            font-weight: 600;
            font-size: 12px;
            text-align: center;
            line-height: 1.2;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .connector-calendar .mcs-day-full-badge {
            align-self: stretch;
            margin-top: 8px;
            padding: 6px 8px;
            border-radius: 6px;
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
            font-weight: 600;
            font-size: 12px;
            text-align: center;
            line-height: 1.2;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .connector-calendar .mpc-calendar-month-title {
                padding: 16px 20px;
                font-size: 18px;
            }

            .connector-calendar .mpc-calendar-day-header {
                padding: 12px 4px;
                font-size: 11px;
            }

            .connector-calendar .mcs-day {
                min-height: 75px;
                padding: 8px 6px 6px 6px;
            }

            .connector-calendar .mcs-day-number {
                font-size: 14px;
            }

            .connector-calendar .mcs-day-price {
                padding: 4px 6px;
                font-size: 11px;
                margin-top: 6px;
            }

            .connector-calendar .mcs-day-full-badge {
                padding: 4px 6px;
                font-size: 11px;
                margin-top: 6px;
            }

            .connector-calendar .mpc-legend-items {
                gap: 16px;
            }
        }

        @media (max-width: 480px) {
            .connector-calendar .mcs-day {
                min-height: 65px;
                padding: 6px 4px 4px 4px;
            }

            .connector-calendar .mcs-day-number {
                font-size: 13px;
            }

            .connector-calendar .mcs-day-price {
                padding: 3px 4px;
                font-size: 10px;
                margin-top: 4px;
            }

            .connector-calendar .mcs-day-full-badge {
                padding: 3px 4px;
                font-size: 10px;
                margin-top: 4px;
            }

            .connector-calendar .mpc-calendar-day-header {
                padding: 10px 2px;
                font-size: 10px;
            }
        }
        </style>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Ensure portal URL is available
            <?php
            $settings = \WP_Minpaku_Connector::get_settings();
            $portal_url = '';
            if (!empty($settings['portal_url'])) {
                if (class_exists('MinpakuConnector\Admin\MPC_Admin_Settings')) {
                    $portal_url = \MinpakuConnector\Admin\MPC_Admin_Settings::normalize_portal_url($settings['portal_url']);
                    if ($portal_url === false) {
                        $portal_url = $settings['portal_url'];
                    }
                } else {
                    $portal_url = $settings['portal_url'];
                }
            }
            ?>
            var connectorPortalUrl = '<?php echo esc_js(untrailingslashit($portal_url)); ?>';

            // Handle calendar day clicks for booking (portal redirection)
            document.querySelectorAll('.connector-calendar .mcs-day').forEach(function(day) {
                day.addEventListener('click', function(e) {
                    e.preventDefault();

                    // Only allow clicks on available days and current month days
                    if (this.dataset.disabled === '1' || this.classList.contains('mcs-day--empty') || this.classList.contains('mcs-day--past')) {
                        return;
                    }

                    var date = this.dataset.ymd;
                    var propertyId = this.dataset.property;

                    if (date && propertyId && connectorPortalUrl) {
                        // Create booking URL for portal
                        var bookingUrl = connectorPortalUrl + '/wp-admin/post-new.php?post_type=mcs_booking' +
                                        '&property_id=' + propertyId +
                                        '&checkin=' + date;

                        console.log('Opening booking URL:', bookingUrl);
                        window.open(bookingUrl, '_blank');
                    } else {
                        console.error('Missing data for booking:', {
                            date: date,
                            propertyId: propertyId,
                            portalUrl: connectorPortalUrl
                        });
                        alert('予約画面への遷移に必要な情報が不足しています。設定を確認してください。');
                    }
                });
            });
        });
        </script>
        <?php

        return ob_get_clean();
    }

    /**
     * Get property ID from shortcode attribute or auto-detect from current context
     */
    private static function get_property_id($provided_id) {
        // If property_id is provided in shortcode, use it
        if (!empty($provided_id)) {
            return intval($provided_id);
        }

        // Check if property_id is in URL parameters
        if (isset($_GET['property_id'])) {
            return intval($_GET['property_id']);
        }

        return 0; // No property ID found
    }

    /**
     * Generate calendar days for a specific month with portal parity
     */
    private static function generate_calendar_days($year, $month, $property_id, $show_prices, $api) {
        $first_day = new \DateTime("$year-$month-01");
        $last_day = new \DateTime($first_day->format('Y-m-t'));
        $start_of_week = clone $first_day;
        $start_of_week->modify('last sunday');

        if ($start_of_week == $first_day) {
            $start_of_week->modify('-7 days');
        }

        $end_of_week = clone $last_day;
        $end_of_week->modify('next saturday');
        if ($end_of_week == $last_day) {
            $end_of_week->modify('+7 days');
        }

        $current_date = clone $start_of_week;
        $output = '';

        // Get availability data from portal API
        $availability_result = $api->get_availability($property_id, 2, null, true);
        $availability_data = [];

        if ($availability_result['success']) {
            $availability_data = $availability_result['data'] ?? [];
        }

        while ($current_date <= $end_of_week) {
            $output .= '<div class="mpc-calendar-week">';

            for ($day = 0; $day < 7; $day++) {
                $is_current_month = ($current_date->format('n') == $month);
                $is_past = ($current_date < new \DateTime('today'));
                $date_string = $current_date->format('Y-m-d');

                // Get availability status
                $availability_status = self::get_availability_status($date_string, $availability_data);

                // Get day classification for colors - Portal Parity
                $day_classification = self::getSimpleDayClasses($date_string, $availability_status);

                $is_available = ($availability_status === 'available');
                $is_disabled = $is_past || !$is_available;

                $cell_classes = $day_classification['css_classes'];
                if (!$is_current_month) {
                    $cell_classes[] = 'mcs-day--empty';
                }
                if ($is_past) {
                    $cell_classes[] = 'mcs-day--past';
                }

                $output .= sprintf(
                    '<div class="%s" data-ymd="%s" data-property="%s" data-disabled="%d" style="background-color: %s;">',
                    esc_attr(implode(' ', $cell_classes)),
                    esc_attr($date_string),
                    esc_attr($property_id),
                    $is_disabled ? 1 : 0,
                    esc_attr($day_classification['background_color'])
                );

                $output .= '<span class="mcs-day-number">' . $current_date->format('j') . '</span>';

                // Add price badge for available days, or 満室 badge for booked days
                if ($is_current_month && !$is_past) {
                    if ($availability_status === 'available' && $show_prices) {
                        $price = self::get_price_for_day($date_string, $availability_data, $property_id);
                        // Force display even if price calculation fails
                        if ($price <= 0) {
                            $price = self::calculate_local_pricing_for_date($date_string, $property_id);
                        }
                        if ($price > 0) {
                            $output .= '<span class="mcs-day-price">¥' . number_format($price) . '</span>';
                        }
                    } elseif ($availability_status === 'full') {
                        $output .= '<span class="mcs-day-full-badge">満室</span>';
                    }
                }

                $output .= '</div>';

                $current_date->add(new \DateInterval('P1D'));
            }

            $output .= '</div>';
        }

        return $output;
    }

    /**
     * Get availability status for a specific date
     */
    private static function get_availability_status($date_string, $availability_data) {
        if (isset($availability_data['availability']) && is_array($availability_data['availability'])) {
            foreach ($availability_data['availability'] as $day_data) {
                if (isset($day_data['date']) && $day_data['date'] === $date_string) {
                    $available = $day_data['available'] ?? true;
                    $status = $day_data['status'] ?? 'available';

                    if (!$available) {
                        switch ($status) {
                            case 'booked':
                            case 'FULL':
                                return 'full';
                            case 'partial':
                            case 'PARTIAL':
                                return 'pending';
                            default:
                                return 'full';
                        }
                    } else {
                        return 'available';
                    }
                }
            }
        }
        return 'available';
    }

    /**
     * Simple day classification for colors - Portal Parity
     */
    private static function getSimpleDayClasses($date_string, $availability_status) {
        $date = new \DateTime($date_string);
        $day_of_week = $date->format('w'); // 0 = Sunday, 6 = Saturday

        $css_classes = ['mcs-day'];
        $background_color = '#FFFFFF'; // Default white

        // Add availability class
        $css_classes[] = "mcs-day--{$availability_status}";

        // Add day type classes for color (same logic as portal)
        if ($availability_status === 'available') {
            if ($day_of_week == 0 || self::isJapaneseHoliday($date_string)) { // Sunday or Holiday
                $css_classes[] = 'mcs-day--sun';
                if (self::isJapaneseHoliday($date_string)) {
                    $css_classes[] = 'mcs-day--holiday';
                }
                $background_color = '#fef2f2'; // Light red
            } elseif ($day_of_week == 6) { // Saturday
                $css_classes[] = 'mcs-day--sat';
                $background_color = '#eff6ff'; // Light blue
            } else { // Weekday
                $css_classes[] = 'mcs-day--weekday';
                $background_color = '#f0fdf4'; // Light green
            }
        } elseif ($availability_status === 'full') {
            $css_classes[] = 'mcs-day--booked';
            $background_color = '#f1f5f9'; // Light gray
        }

        return array(
            'css_classes' => $css_classes,
            'background_color' => $background_color
        );
    }

    /**
     * Check if date is a Japanese holiday - Portal Parity
     */
    private static function isJapaneseHoliday($date_string) {
        $holidays = [
            // 2025 holidays
            '2025-01-01', '2025-01-13', '2025-02-11', '2025-02-23',
            '2025-03-20', '2025-04-29', '2025-05-03', '2025-05-04',
            '2025-05-05', '2025-07-21', '2025-08-11', '2025-09-15',
            '2025-09-23', '2025-10-13', '2025-11-03', '2025-11-23',
            // 2024 holidays (for historical data)
            '2024-01-01', '2024-01-08', '2024-02-11', '2024-02-23',
            '2024-03-20', '2024-04-29', '2024-05-03', '2024-05-04',
            '2024-05-05', '2024-07-15', '2024-08-11', '2024-09-16',
            '2024-09-22', '2024-10-14', '2024-11-03', '2024-11-23',
            // 2026 holidays (for future bookings)
            '2026-01-01', '2026-01-12', '2026-02-11', '2026-02-23',
            '2026-03-20', '2026-04-29', '2026-05-03', '2026-05-04',
            '2026-05-05', '2026-07-20', '2026-08-11', '2026-09-21',
            '2026-09-22', '2026-10-12', '2026-11-03', '2026-11-23'
        ];

        return in_array($date_string, $holidays);
    }

    /**
     * Get price for a specific date with weekend/holiday pricing
     */
    private static function get_price_for_day($date_string, $availability_data, $property_id) {
        // First, check the pricing array for date-specific pricing from portal
        if (isset($availability_data['pricing']) && is_array($availability_data['pricing'])) {
            foreach ($availability_data['pricing'] as $pricing_data) {
                if (isset($pricing_data['date']) && $pricing_data['date'] === $date_string) {
                    if (isset($pricing_data['price']) && is_numeric($pricing_data['price'])) {
                        $price = floatval($pricing_data['price']);
                        if ($price > 0) {
                            return $price;
                        }
                    }
                }
            }
        }

        // Then check availability array for pricing from portal
        if (isset($availability_data['availability']) && is_array($availability_data['availability'])) {
            foreach ($availability_data['availability'] as $day_data) {
                if (isset($day_data['date']) && $day_data['date'] === $date_string) {
                    if (isset($day_data['price']) && is_numeric($day_data['price'])) {
                        $price = floatval($day_data['price']);
                        if ($price > 0) {
                            return $price;
                        }
                    }
                    if (isset($day_data['min_price']) && is_numeric($day_data['min_price'])) {
                        $price = floatval($day_data['min_price']);
                        if ($price > 0) {
                            return $price;
                        }
                    }
                }
            }
        }

        // If no portal pricing available, calculate local pricing with weekend/holiday surcharges
        return self::calculate_local_pricing_for_date($date_string, $property_id);
    }

    /**
     * Calculate local pricing for date with weekend/holiday surcharges
     */
    private static function calculate_local_pricing_for_date($date_string, $property_id) {
        try {
            // Load required pricing calculation classes from main project if available
            $project_root = dirname(dirname(dirname(dirname(__FILE__))));
            if (file_exists($project_root . '/includes/Calendar/DayClassifier.php')) {
                require_once $project_root . '/includes/Calendar/DayClassifier.php';
            }

            // Get pricing settings with error handling
            $pricing_settings = self::get_pricing_settings();
            $base_price = floatval($pricing_settings['base_nightly_price'] ?? 15000);

            // Property-specific base rates (same as Embed.php)
            $property_base_rates = [
                17 => 18000.0,
                16 => 16000.0,
                15 => 14000.0,
            ];

            if (isset($property_base_rates[$property_id])) {
                $base_price = $property_base_rates[$property_id];
            } elseif ($base_price <= 0) {
                $base_price = 15000.0; // Default fallback
            }

            // Check for seasonal rules first (highest priority)
            $seasonal_rules = $pricing_settings['seasonal_rules'] ?? [];
            $seasonal_price = self::apply_seasonal_rules_to_price($date_string, $base_price, $seasonal_rules);
            if ($seasonal_price !== $base_price) {
                return $seasonal_price; // Seasonal rule applied
            }

            // Calculate weekend/holiday surcharges
            $date = new \DateTime($date_string);
            $day_of_week = $date->format('w'); // 0 = Sunday, 6 = Saturday
            $is_holiday = self::isJapaneseHoliday($date_string);

            $eve_surcharge = 0;

            // Try to use DayClassifier if available
            if (class_exists('\MinpakuConnector\Calendar\DayClassifier')) {
                try {
                    $eve_info = \MinpakuConnector\Calendar\DayClassifier::checkEveSurcharges($date_string);

                    if ($eve_info['has_surcharge']) {
                        switch ($eve_info['surcharge_type']) {
                            case 'saturday_eve':
                                $eve_surcharge = floatval($pricing_settings['eve_surcharge_sat'] ?? 2000);
                                break;
                            case 'sunday_eve':
                                $eve_surcharge = floatval($pricing_settings['eve_surcharge_sun'] ?? 1000);
                                break;
                            case 'holiday_eve':
                                $eve_surcharge = floatval($pricing_settings['eve_surcharge_holiday'] ?? 1500);
                                break;
                        }
                    }
                } catch (Exception $e) {
                    // Fallback to simple calculation if DayClassifier fails
                    $eve_surcharge = 0;
                }
            }

            // Apply direct weekend/holiday surcharges if no eve surcharge calculated
            if ($eve_surcharge == 0) {
                if ($is_holiday) {
                    $eve_surcharge = floatval($pricing_settings['eve_surcharge_holiday'] ?? 1500);
                } elseif ($day_of_week == 6) { // Saturday
                    $eve_surcharge = floatval($pricing_settings['eve_surcharge_sat'] ?? 2000);
                } elseif ($day_of_week == 0) { // Sunday
                    $eve_surcharge = floatval($pricing_settings['eve_surcharge_sun'] ?? 1000);
                }
            }

            return $base_price + $eve_surcharge;

        } catch (Exception $e) {
            // Ultimate fallback - return property-specific base rate
            $property_base_rates = [
                17 => 18000.0,
                16 => 16000.0,
                15 => 14000.0,
            ];
            return $property_base_rates[$property_id] ?? 15000.0;
        }
    }

    /**
     * Apply seasonal rules to base price
     */
    private static function apply_seasonal_rules_to_price($date, $base_price, $seasonal_rules) {
        if (empty($seasonal_rules) || !is_array($seasonal_rules)) {
            return $base_price;
        }

        foreach ($seasonal_rules as $rule) {
            if (!isset($rule['date_from']) || !isset($rule['date_to']) || !isset($rule['mode']) || !isset($rule['amount'])) {
                continue;
            }

            $date_from = $rule['date_from'];
            $date_to = $rule['date_to'];

            // Check if date falls within this rule's range
            if ($date >= $date_from && $date <= $date_to) {
                $amount = floatval($rule['amount']);

                if ($rule['mode'] === 'override') {
                    return $amount; // Replace base price
                } elseif ($rule['mode'] === 'add') {
                    return $base_price + $amount; // Add to base price
                }
            }
        }

        return $base_price; // No seasonal rule applied
    }

    /**
     * Get pricing settings
     */
    private static function get_pricing_settings() {
        if (class_exists('MinpakuConnector\Admin\MPC_Admin_Settings')) {
            return \MinpakuConnector\Admin\MPC_Admin_Settings::get_pricing_settings();
        }

        // Fallback defaults with proper weekend/holiday surcharges
        return array(
            'base_nightly_price' => 15000,
            'cleaning_fee_per_booking' => 3000,
            'eve_surcharge_sat' => 2000,
            'eve_surcharge_sun' => 1000,
            'eve_surcharge_holiday' => 1500,
            'seasonal_rules' => array(),
            'blackout_ranges' => array()
        );
    }

    /**
     * Render modal calendar button
     */
    private static function render_modal_button($property_id, $months, $show_prices, $property_title) {
        // Enqueue modal scripts and styles
        self::enqueue_modal_assets();

        $button_id = 'connector-calendar-btn-' . uniqid();

        ob_start();
        ?>
        <div class="connector-calendar-modal-wrapper">
            <div class="connector-calendar-button-container">
                <button id="<?php echo esc_attr($button_id); ?>"
                        class="connector-calendar-modal-button"
                        data-property-id="<?php echo esc_attr($property_id); ?>"
                        data-property-title="<?php echo esc_attr($property_title); ?>"
                        data-months="<?php echo esc_attr($months); ?>"
                        data-show-prices="<?php echo $show_prices ? '1' : '0'; ?>">
                    <span class="connector-calendar-icon">📅</span>
                    <span class="connector-calendar-text"><?php echo esc_html__('カレンダーを表示', 'wp-minpaku-connector'); ?></span>
                </button>
            </div>
        </div>

        <!-- Modal Structure -->
        <div id="connector-calendar-modal-<?php echo esc_attr($property_id); ?>" class="connector-calendar-modal-overlay" style="display: none;">
            <div class="connector-calendar-modal-content">
                <div class="connector-calendar-modal-header">
                    <h3 class="connector-calendar-modal-title"><?php echo esc_html($property_title); ?> - <?php echo esc_html__('空室カレンダー', 'wp-minpaku-connector'); ?></h3>
                    <button class="connector-calendar-modal-close">&times;</button>
                </div>
                <div class="connector-calendar-modal-body">
                    <div class="connector-calendar-modal-loading">
                        <div class="connector-calendar-loading-spinner"></div>
                        <p><?php echo esc_html__('カレンダーを読み込み中...', 'wp-minpaku-connector'); ?></p>
                    </div>
                    <div class="connector-calendar-modal-calendar-content" style="display: none;"></div>
                </div>
            </div>
        </div>

        <style>
        .connector-calendar-modal-wrapper {
            margin: 20px 0;
        }

        .connector-calendar-modal-button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .connector-calendar-modal-button:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }

        .connector-calendar-icon {
            font-size: 18px;
        }

        .connector-calendar-modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 999999;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .connector-calendar-modal-content {
            background: white;
            border-radius: 12px;
            max-width: 90vw;
            max-height: 90vh;
            width: 900px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }

        .connector-calendar-modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px 24px;
            border-bottom: 1px solid #eee;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .connector-calendar-modal-title {
            margin: 0;
            font-size: 18px;
            font-weight: 600;
        }

        .connector-calendar-modal-close {
            background: none;
            border: none;
            font-size: 24px;
            color: white;
            cursor: pointer;
            padding: 4px;
            border-radius: 4px;
            transition: background-color 0.2s ease;
            line-height: 1;
        }

        .connector-calendar-modal-close:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .connector-calendar-modal-body {
            padding: 24px;
            max-height: calc(90vh - 80px);
            overflow-y: auto;
        }

        .connector-calendar-modal-loading {
            text-align: center;
            padding: 40px;
        }

        .connector-calendar-loading-spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 16px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        body.connector-calendar-modal-open {
            overflow: hidden;
        }
        </style>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Connector Calendar Modal Script Loaded');

            // Modal button click handler
            var button = document.getElementById('<?php echo esc_js($button_id); ?>');
            if (button) {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    console.log('Modal button clicked');

                    var propertyId = this.getAttribute('data-property-id');
                    var propertyTitle = this.getAttribute('data-property-title');
                    var months = this.getAttribute('data-months');
                    var showPrices = this.getAttribute('data-show-prices');

                    console.log('Opening modal for property:', propertyId);
                    openConnectorCalendarModal(propertyId, propertyTitle, months, showPrices);
                });
            }

            // Modal close handlers
            document.addEventListener('click', function(e) {
                if (e.target.classList.contains('connector-calendar-modal-close') ||
                    e.target.classList.contains('connector-calendar-modal-overlay')) {
                    closeConnectorCalendarModal();
                }
            });

            // ESC key handler
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    closeConnectorCalendarModal();
                }
            });
        });

        function openConnectorCalendarModal(propertyId, propertyTitle, months, showPrices) {
            console.log('openConnectorCalendarModal called with:', propertyId, propertyTitle, months, showPrices);

            var modal = document.getElementById('connector-calendar-modal-' + propertyId);
            console.log('Modal element found:', modal);

            if (!modal) {
                console.error('Modal not found for ID: connector-calendar-modal-' + propertyId);
                return;
            }

            var loadingDiv = modal.querySelector('.connector-calendar-modal-loading');
            var contentDiv = modal.querySelector('.connector-calendar-modal-calendar-content');

            // Show modal
            modal.style.display = 'flex';
            document.body.classList.add('connector-calendar-modal-open');

            console.log('Modal should now be visible');

            // Show loading
            if (loadingDiv) loadingDiv.style.display = 'block';
            if (contentDiv) {
                contentDiv.style.display = 'none';
                contentDiv.innerHTML = '';
            }

            // Generate calendar content via AJAX
            setTimeout(function() {
                var formData = new FormData();
                formData.append('action', 'connector_calendar_modal_content');
                formData.append('property_id', propertyId);
                formData.append('months', months);
                formData.append('show_prices', showPrices);
                formData.append('nonce', '<?php echo wp_create_nonce('connector_calendar_modal'); ?>');

                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (loadingDiv) loadingDiv.style.display = 'none';
                    if (data.success) {
                        if (contentDiv) {
                            contentDiv.innerHTML = data.data;
                            contentDiv.style.display = 'block';
                        }
                    } else {
                        if (contentDiv) {
                            contentDiv.innerHTML = '<div class="connector-calendar-error">カレンダーの読み込みに失敗しました。</div>';
                            contentDiv.style.display = 'block';
                        }
                    }
                })
                .catch(error => {
                    console.error('AJAX Error:', error);
                    if (loadingDiv) loadingDiv.style.display = 'none';
                    if (contentDiv) {
                        contentDiv.innerHTML = '<div class="connector-calendar-error">ネットワークエラーが発生しました。</div>';
                        contentDiv.style.display = 'block';
                    }
                });
            }, 100);
        }

        function closeConnectorCalendarModal() {
            var modals = document.querySelectorAll('.connector-calendar-modal-overlay');
            modals.forEach(function(modal) {
                if (modal.style.display !== 'none') {
                    modal.style.display = 'none';
                }
            });
            document.body.classList.remove('connector-calendar-modal-open');
        }
        </script>
        <?php
        return ob_get_clean();
    }

    /**
     * Enqueue modal assets
     */
    private static function enqueue_modal_assets() {
        // Enqueue jQuery if not already loaded
        wp_enqueue_script('jquery');
    }

    /**
     * AJAX handler for modal calendar content
     */
    public static function ajax_modal_content() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'connector_calendar_modal')) {
            wp_send_json_error('Invalid nonce');
            return;
        }

        $property_id = intval($_POST['property_id'] ?? 0);
        $months = intval($_POST['months'] ?? 2);
        $show_prices = ($_POST['show_prices'] ?? '0') === '1';

        if (!$property_id) {
            wp_send_json_error('Invalid property ID');
            return;
        }

        // Generate calendar content
        $calendar_content = self::render_calendar([
            'property_id' => $property_id,
            'months' => $months,
            'show_prices' => $show_prices ? 'true' : 'false',
            'modal' => 'false' // Prevent recursive modal rendering
        ]);

        wp_send_json_success($calendar_content);
    }
}