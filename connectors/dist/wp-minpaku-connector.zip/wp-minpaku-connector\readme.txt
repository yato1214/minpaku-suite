﻿=== WP Minpaku Connector ===
Contributors: yato1214
Tags: minpaku, vacation rental, property management, booking
Requires at least: 5.0
Tested up to: 6.3
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect your WordPress site to Minpaku Suite portal to display property listings and availability calendars.

== Description ==

WP Minpaku Connector allows you to connect your WordPress site to a Minpaku Suite portal to display:

* Property listings with details and images
* Availability calendars for specific properties
* Property details and amenities
* Booking quotes and pricing

== Installation ==

1. Upload the plugin files to /wp-content/plugins/wp-minpaku-connector/
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to Settings > Minpaku Connector to configure the connection
4. Get your API credentials from your Minpaku Suite portal
5. Test the connection and start using shortcodes

== Shortcodes ==

* [minpaku_connector type="properties"] - Display property listings
* [minpaku_connector type="calendar" property_id="123"] - Show availability calendar
* [minpaku_connector type="property" property_id="123"] - Display property details

== Changelog ==

= 1.0.1 =
* Enhanced Portal Base URL validation for development environments
* Support for .local, .test, localhost domains with ports
* Improved error handling and user feedback
* Comprehensive debug logging
* Stabilized activation hooks
* Updated Japanese translations

= 1.0.0 =
* Initial release
* Basic connector functionality
* Property listings and calendar display
* HMAC authentication
