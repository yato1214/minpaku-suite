﻿=== WP Minpaku Connector ===
Contributors: yato1214
Tags: minpaku, vacation rental, property management, booking
Requires at least: 5.0
Tested up to: 6.3
Requires PHP: 7.4
Stable tag: 1.0.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect your WordPress site to Minpaku Suite portal to display property listings and availability calendars.

== Description ==

WP Minpaku Connector allows you to connect your WordPress site to a Minpaku Suite portal to display:

* Property listings with details and images
* Availability calendars for specific properties
* Property details and amenities
* Booking quotes and pricing

== Installation ==

1. Upload the plugin files to /wp-content/plugins/wp-minpaku-connector/
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to Settings > Minpaku Connector to configure the connection
4. Get your API credentials from your Minpaku Suite portal
5. Test the connection and start using shortcodes

== Shortcodes ==

**Basic Shortcodes:**
* [minpaku_connector type="properties"] - Display property listings
* [minpaku_connector type="calendar" property_id="123"] - Show availability calendar
* [minpaku_connector type="property" property_id="123"] - Display property details

**New Pricing Shortcodes:**
* [minpaku_calendar property_id="123" show_prices="true"] - Calendar with price badges
* [minpaku_property_card property_id="123" show_price="true"] - Single property card with quick quote
* [minpaku_property_list limit="12" columns="3" show_prices="true"] - Property grid with pricing

== Changelog ==

= 1.0.4 =
* NEW: Enhanced calendar availability visualization with color-coded status
* NEW: Improved price badge positioning at bottom of calendar cells
* NEW: Modern calendar design with gradient backgrounds and hover effects
* NEW: Enhanced quote modal with improved usability and design
* NEW: Availability indicators with status tooltips (Available/Partial/Full)
* NEW: Mobile-responsive calendar improvements
* FIXED: Calendar cell layout and price display positioning
* Enhanced: Visual feedback for booking status and pricing
* Updated: Portal calendar with same modern design improvements

= 1.0.2 =
* NEW: Complete pricing integration with calendar price badges and quote modals
* NEW: Property card shortcodes with quick pricing display
* NEW: Advanced caching system (memory, WordPress transients, session storage)
* NEW: HMAC authenticated QuoteApi client for secure pricing requests
* NEW: Intersection Observer for lazy loading price badges
* NEW: Mobile-responsive design with dark mode support
* Enhanced: Multi-level request coalescing and error handling
* Enhanced: Accessibility features with ARIA support and keyboard navigation
* Enhanced: Internationalization support for pricing strings
* Updated: Modern UI design with animations and loading states

= 1.0.0 =
* Initial release
* Basic connector functionality
* Property listings and calendar display
* HMAC authentication
