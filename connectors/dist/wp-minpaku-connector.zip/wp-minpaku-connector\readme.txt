=== WP Minpaku Connector ===
Contributors: yato1214
Tags: minpaku, vacation rental, property listings, availability calendar, connector
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect your WordPress site to Minpaku Suite portal to display property listings and availability calendars.

== Description ==

WP Minpaku Connector allows you to connect your WordPress site to a Minpaku Suite portal and display property listings and availability calendars using simple shortcodes.

**Features:**
* Easy connection to Minpaku Suite portal
* Display property listings with customizable grid layout
* Show availability calendars for specific properties
* Multilingual support (English/Japanese)
* Responsive design
* Simple shortcode-based implementation

**Shortcodes:**
* [minpaku_connector type="properties" limit="12" columns="3"] - Display property listings
* [minpaku_connector type="availability" property_id="123" months="2"] - Show availability calendar
* [minpaku_connector type="property" property_id="123"] - Display single property details

== Installation ==

1. Upload the plugin files to /wp-content/plugins/wp-minpaku-connector/
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Configure the connection in Settings > Minpaku Connector
4. Get your API credentials from your Minpaku Suite portal admin
5. Test the connection and start using shortcodes

== Configuration ==

1. Go to Settings > Minpaku Connector
2. Enter your portal connection details:
   * Portal Base URL (e.g., https://yourportal.com)
   * Site ID (from portal connector settings)
   * API Key (from portal connector settings)
   * Secret (from portal connector settings)
3. Click "Test Connection" to verify
4. Use shortcodes on your pages and posts

== Frequently Asked Questions ==

= How do I get API credentials? =

Log in to your Minpaku Suite portal admin, go to Minpaku > Settings > Connector, enable the connector, add your domain to allowed domains, and generate API keys for your site.

= What if the connection test fails? =

Check that:
* All credentials are entered correctly
* Your domain is added to allowed domains in the portal
* The portal URL is accessible
* Your server time is synchronized

== Changelog ==

= 1.0.1 =
* Initial release
* Property listings display
* Availability calendar integration
* Connection testing
* Multilingual support (EN/JA)
* Responsive design

== Support ==

For support, please visit: https://github.com/yato1214/minpaku-suite/issues
