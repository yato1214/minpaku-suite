<?php
/**
 * Plugin Name: WP Minpaku Connector
 * Plugin URI: https://github.com/yato1214/minpaku-suite
 * Description: Connect your WordPress site to Minpaku Suite portal to display property listings and availability calendars.
 * Version: 1.0.1
 * Author: Yato1214
 * Text Domain: wp-minpaku-connector
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * Network: false
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WP_MINPAKU_CONNECTOR_VERSION', '1.0.1');
define('WP_MINPAKU_CONNECTOR_PLUGIN_FILE', __FILE__);
define('WP_MINPAKU_CONNECTOR_PATH', plugin_dir_path(__FILE__));
define('WP_MINPAKU_CONNECTOR_URL', plugin_dir_url(__FILE__));

// Load plugin dependencies immediately
require_once WP_MINPAKU_CONNECTOR_PATH . 'includes/Admin/Settings.php';
require_once WP_MINPAKU_CONNECTOR_PATH . 'includes/Client/Signer.php';
require_once WP_MINPAKU_CONNECTOR_PATH . 'includes/Client/Api.php';
require_once WP_MINPAKU_CONNECTOR_PATH . 'includes/Shortcodes/Embed.php';

/**
 * Load text domain for translations
 */
function wp_minpaku_connector_load_textdomain() {
    \load_plugin_textdomain(
        'wp-minpaku-connector',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages'
    );
}
\add_action('plugins_loaded', 'wp_minpaku_connector_load_textdomain');

/**
 * Main plugin class
 */
class WP_Minpaku_Connector {

    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init();
    }

    /**
     * Initialize the plugin
     */
    private function init() {
        \add_action('init', array($this, 'init_components'), 10);

        // Admin hooks
        \add_action('admin_menu', array($this, 'add_admin_menu'));
        \add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));

        // Frontend hooks
        \add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));

        // AJAX hooks
        \add_action('wp_ajax_mpc_test_connection', array($this, 'ajax_test_connection'));

        // HTTP filters for .local domain support
        $this->setup_http_filters();
    }

    /**
     * Initialize components
     */
    public function init_components() {
        // Initialize admin settings
        if (\is_admin()) {
            MinpakuConnector\Admin\MPC_Admin_Settings::init();
        }

        // Initialize shortcodes
        MinpakuConnector\Shortcodes\MPC_Shortcodes_Embed::init();
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        \add_options_page(
            \__('Minpaku Connector', 'wp-minpaku-connector'),
            \__('Minpaku Connector', 'wp-minpaku-connector'),
            'manage_options',
            'wp-minpaku-connector',
            array($this, 'render_admin_page')
        );
    }

    /**
     * Render admin page
     */
    public function render_admin_page() {
        if (\class_exists('MinpakuConnector\Admin\MPC_Admin_Settings')) {
            MinpakuConnector\Admin\MPC_Admin_Settings::render_page();
        }
    }

    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook_suffix) {
        if ($hook_suffix !== 'settings_page_wp-minpaku-connector') {
            return;
        }

        \wp_enqueue_style(
            'wp-minpaku-connector-admin',
            WP_MINPAKU_CONNECTOR_URL . 'assets/admin.css',
            array(),
            WP_MINPAKU_CONNECTOR_VERSION
        );

        \wp_enqueue_script(
            'wp-minpaku-connector-admin',
            WP_MINPAKU_CONNECTOR_URL . 'assets/admin.js',
            array('jquery'),
            WP_MINPAKU_CONNECTOR_VERSION,
            true
        );

        \wp_localize_script('wp-minpaku-connector-admin', 'mpcAdmin', array(
            'ajaxUrl' => \admin_url('admin-ajax.php'),
            'nonce' => \wp_create_nonce('mpc_admin_nonce'),
            'strings' => array(
                'testing' => \__('Testing connection...', 'wp-minpaku-connector'),
                'success' => \__('Connection successful!', 'wp-minpaku-connector'),
                'error' => \__('Connection failed. Please check your settings.', 'wp-minpaku-connector')
            )
        ));
    }

    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_frontend_scripts() {
        \wp_enqueue_style(
            'wp-minpaku-connector',
            WP_MINPAKU_CONNECTOR_URL . 'assets/connector.css',
            array(),
            WP_MINPAKU_CONNECTOR_VERSION
        );
    }

    /**
     * AJAX handler for connection test
     */
    public function ajax_test_connection() {
        \check_ajax_referer('mpc_admin_nonce', 'nonce');

        if (!\current_user_can('manage_options')) {
            \wp_die(\__('You do not have permission to perform this action.', 'wp-minpaku-connector'));
        }

        if (\class_exists('MinpakuConnector\Client\MPC_Client_Api')) {
            $api = new MinpakuConnector\Client\MPC_Client_Api();
            $result = $api->test_connection();

            if ($result['success']) {
                \wp_send_json_success($result);
            } else {
                \wp_send_json_error($result);
            }
        } else {
            \wp_send_json_error(array(
                'message' => \__('API client not available.', 'wp-minpaku-connector')
            ));
        }
    }

    /**
     * Get plugin settings
     */
    public static function get_settings() {
        return \get_option('wp_minpaku_connector_settings', array(
            'portal_url' => '',
            'api_key' => '',
            'secret' => '',
            'site_id' => ''
        ));
    }

    /**
     * Update plugin settings
     */
    public static function update_settings($settings) {
        return \update_option('wp_minpaku_connector_settings', $settings);
    }

    /**
     * Setup HTTP filters to allow .local domains and handle external blocking
     */
    private function setup_http_filters() {
        // Allow .local domains in wp_remote_* requests
        \add_filter('http_request_host_is_external', array($this, 'allow_local_domains'), 10, 3);

        // Handle wp_safe_remote_request blocking
        \add_filter('pre_http_request', array($this, 'handle_local_domain_requests'), 10, 3);

        // Temporarily disable WP_HTTP_BLOCK_EXTERNAL for our requests
        \add_filter('http_request_args', array($this, 'maybe_unblock_external_requests'), 10, 2);
    }

    /**
     * Allow .local domains to be treated as internal
     */
    public function allow_local_domains($is_external, $host, $url) {
        // Check if this is our connector request
        if ($this->is_connector_request($url)) {
            // Allow .local, .test, localhost, and IPv4 addresses
            if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                return false; // IPv4 addresses are considered internal
            }

            if ($host === 'localhost') {
                return false; // localhost is internal
            }

            if (strpos($host, '.') !== false) {
                $tld = substr(strrchr($host, '.'), 1);
                if (in_array($tld, ['local', 'test', 'localdomain'], true)) {
                    return false; // Development TLDs are internal
                }
            }
        }

        return $is_external;
    }

    /**
     * Handle requests to .local domains by bypassing wp_safe_remote_request restrictions
     */
    public function handle_local_domain_requests($response, $parsed_args, $url) {
        // Only handle our connector requests
        if (!$this->is_connector_request($url)) {
            return $response;
        }

        $parsed_url = wp_parse_url($url);
        $host = $parsed_url['host'] ?? '';

        // Check if this is a .local domain or development environment
        $is_dev_domain = false;

        if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $is_dev_domain = true;
        } elseif ($host === 'localhost') {
            $is_dev_domain = true;
        } elseif (strpos($host, '.') !== false) {
            $tld = substr(strrchr($host, '.'), 1);
            $is_dev_domain = in_array($tld, ['local', 'test', 'localdomain'], true);
        }

        if ($is_dev_domain) {
            // Temporarily set WP_HTTP_BLOCK_EXTERNAL to false for this request
            if (defined('WP_HTTP_BLOCK_EXTERNAL') && WP_HTTP_BLOCK_EXTERNAL) {
                // Create a modified args array that forces the request to proceed
                $parsed_args['reject_unsafe_urls'] = false;
                $parsed_args['_connector_override'] = true;

                // Debug logging
                if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
                    error_log('[minpaku-connector] Allowing request to development domain: ' . $host);
                }
            }
        }

        return $response;
    }

    /**
     * Modify request arguments to allow external requests for connector URLs
     */
    public function maybe_unblock_external_requests($args, $url) {
        // Only modify our connector requests
        if (!$this->is_connector_request($url)) {
            return $args;
        }

        $parsed_url = wp_parse_url($url);
        $host = $parsed_url['host'] ?? '';

        // Check if this is a development domain
        $is_dev_domain = false;

        if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $is_dev_domain = true;
        } elseif ($host === 'localhost') {
            $is_dev_domain = true;
        } elseif (strpos($host, '.') !== false) {
            $tld = substr(strrchr($host, '.'), 1);
            $is_dev_domain = in_array($tld, ['local', 'test', 'localdomain'], true);
        }

        if ($is_dev_domain) {
            // Force allow external requests for development domains
            $args['reject_unsafe_urls'] = false;

            // Add a filter to temporarily disable WP_HTTP_BLOCK_EXTERNAL
            if (defined('WP_HTTP_BLOCK_EXTERNAL') && WP_HTTP_BLOCK_EXTERNAL) {
                \add_filter('pre_option_wp_http_block_external', '__return_false', 999);

                // Remove the filter after the request
                \add_action('http_api_curl', array($this, 'restore_http_block_external'), 999);
                \add_action('http_api_transports', array($this, 'restore_http_block_external'), 999);
            }

            // Debug logging
            if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
                error_log('[minpaku-connector] Modified request args for development domain: ' . $host);
            }
        }

        return $args;
    }

    /**
     * Restore the WP_HTTP_BLOCK_EXTERNAL setting after request
     */
    public function restore_http_block_external() {
        \remove_filter('pre_option_wp_http_block_external', '__return_false', 999);
    }

    /**
     * Check if the URL is a connector-related request
     */
    private function is_connector_request($url) {
        // Check if URL contains connector endpoints
        return (strpos($url, '/wp-json/minpaku/v1/connector/') !== false);
    }
}

/**
 * Plugin activation hook
 */
if (!function_exists('wp_minpaku_connector_activate')) {
    function wp_minpaku_connector_activate() {
        // Security check
        if (!\current_user_can('activate_plugins')) {
            return;
        }

        // Set default options
        if (!\get_option('wp_minpaku_connector_settings')) {
            \add_option('wp_minpaku_connector_settings', array(
                'portal_url' => '',
                'api_key' => '',
                'secret' => '',
                'site_id' => ''
            ));
        }

        // Flush rewrite rules
        \flush_rewrite_rules();
    }
}

/**
 * Plugin deactivation hook
 */
function wp_minpaku_connector_deactivate() {
    // Flush rewrite rules
    \flush_rewrite_rules();
}

/**
 * Initialize the plugin
 */
function wp_minpaku_connector_init() {
    WP_Minpaku_Connector::get_instance();
}

// Register hooks - dependencies are already loaded above
\register_activation_hook(__FILE__, 'wp_minpaku_connector_activate');
\register_deactivation_hook(__FILE__, 'wp_minpaku_connector_deactivate');
\add_action('plugins_loaded', 'wp_minpaku_connector_init', 5);