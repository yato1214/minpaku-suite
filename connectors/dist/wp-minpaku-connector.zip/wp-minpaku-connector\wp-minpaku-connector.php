<?php
/**
 * Plugin Name: WP Minpaku Connector
 * Plugin URI: https://github.com/yato1214/minpaku-suite
 * Description: Connect your WordPress site to Minpaku Suite portal to display property listings and availability calendars.
 * Version: 1.0.0
 * Author: Yato1214
 * Text Domain: wp-minpaku-connector
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * Network: false
 */

namespace MinpakuConnector;

if (!defined('ABSPATH')) {
    exit;
}

define('WP_MINPAKU_CONNECTOR_VERSION', '1.0.0');
define('WP_MINPAKU_CONNECTOR_PLUGIN_FILE', __FILE__);
define('WP_MINPAKU_CONNECTOR_PATH', plugin_dir_path(__FILE__));
define('WP_MINPAKU_CONNECTOR_URL', plugin_dir_url(__FILE__));

/**
 * Load text domain for translations
 */
function wp_minpaku_connector_load_textdomain() {
    load_plugin_textdomain(
        'wp-minpaku-connector',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages'
    );
}
add_action('plugins_loaded', 'wp_minpaku_connector_load_textdomain');

/**
 * Main plugin class
 */
class MPC_Minpaku_Connector {

    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init();
    }

    /**
     * Initialize the plugin
     */
    private function init() {
        add_action('plugins_loaded', array($this, 'load_dependencies'), 10);
        add_action('init', array($this, 'init_components'), 10);

        // Admin hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));

        // Frontend hooks
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));

        // AJAX hooks
        add_action('wp_ajax_mpc_test_connection', array($this, 'ajax_test_connection'));
    }

    /**
     * Load plugin dependencies
     */
    public function load_dependencies() {
        // Load admin settings
        require_once WP_MINPAKU_CONNECTOR_PATH . 'includes/Admin/Settings.php';

        // Load client classes
        require_once WP_MINPAKU_CONNECTOR_PATH . 'includes/Client/Signer.php';
        require_once WP_MINPAKU_CONNECTOR_PATH . 'includes/Client/Api.php';

        // Load shortcodes
        require_once WP_MINPAKU_CONNECTOR_PATH . 'includes/Shortcodes/Embed.php';
    }

    /**
     * Initialize components
     */
    public function init_components() {
        // Initialize admin settings
        if (is_admin()) {
            Admin\MPC_Admin_Settings::init();
        }

        // Initialize shortcodes
        Shortcodes\MPC_Shortcodes_Embed::init();
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_options_page(
            __('Minpaku Connector', 'wp-minpaku-connector'),
            __('Minpaku Connector', 'wp-minpaku-connector'),
            'manage_options',
            'wp-minpaku-connector',
            array($this, 'render_admin_page')
        );
    }

    /**
     * Render admin page
     */
    public function render_admin_page() {
        if (class_exists('MinpakuConnector\Admin\MPC_Admin_Settings')) {
            Admin\MPC_Admin_Settings::render_page();
        }
    }

    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook_suffix) {
        if ($hook_suffix !== 'settings_page_wp-minpaku-connector') {
            return;
        }

        wp_enqueue_style(
            'wp-minpaku-connector-admin',
            WP_MINPAKU_CONNECTOR_URL . 'assets/admin.css',
            array(),
            WP_MINPAKU_CONNECTOR_VERSION
        );

        wp_enqueue_script(
            'wp-minpaku-connector-admin',
            WP_MINPAKU_CONNECTOR_URL . 'assets/admin.js',
            array('jquery'),
            WP_MINPAKU_CONNECTOR_VERSION,
            true
        );

        wp_localize_script('wp-minpaku-connector-admin', 'mpcAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mpc_admin_nonce'),
            'strings' => array(
                'testing' => __('Testing connection...', 'wp-minpaku-connector'),
                'success' => __('Connection successful!', 'wp-minpaku-connector'),
                'error' => __('Connection failed. Please check your settings.', 'wp-minpaku-connector')
            )
        ));
    }

    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_frontend_scripts() {
        wp_enqueue_style(
            'wp-minpaku-connector',
            WP_MINPAKU_CONNECTOR_URL . 'assets/connector.css',
            array(),
            WP_MINPAKU_CONNECTOR_VERSION
        );
    }

    /**
     * AJAX handler for connection test
     */
    public function ajax_test_connection() {
        check_ajax_referer('mpc_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have permission to perform this action.', 'wp-minpaku-connector'));
        }

        if (class_exists('MinpakuConnector\Client\MPC_Client_Api')) {
            $api = new Client\MPC_Client_Api();
            $result = $api->test_connection();

            if ($result['success']) {
                wp_send_json_success($result);
            } else {
                wp_send_json_error($result);
            }
        } else {
            wp_send_json_error(array(
                'message' => __('API client not available.', 'wp-minpaku-connector')
            ));
        }
    }

    /**
     * Get plugin settings
     */
    public static function get_settings() {
        return get_option('wp_minpaku_connector_settings', array(
            'portal_url' => '',
            'api_key' => '',
            'secret' => '',
            'site_id' => ''
        ));
    }

    /**
     * Update plugin settings
     */
    public static function update_settings($settings) {
        return update_option('wp_minpaku_connector_settings', $settings);
    }
}

/**
 * Plugin activation hook
 */
function wp_minpaku_connector_activate() {
    // Set default options
    if (!get_option('wp_minpaku_connector_settings')) {
        add_option('wp_minpaku_connector_settings', array(
            'portal_url' => '',
            'api_key' => '',
            'secret' => '',
            'site_id' => ''
        ));
    }

    // Flush rewrite rules
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'wp_minpaku_connector_activate');

/**
 * Plugin deactivation hook
 */
function wp_minpaku_connector_deactivate() {
    // Flush rewrite rules
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'wp_minpaku_connector_deactivate');

/**
 * Initialize the plugin
 */
function wp_minpaku_connector_init() {
    MPC_Minpaku_Connector::get_instance();
}
add_action('plugins_loaded', 'wp_minpaku_connector_init', 5);