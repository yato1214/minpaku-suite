﻿=== WP Minpaku Connector ===
Contributors: minpaku-suite
Tags: booking, calendar, minpaku, vacation-rental
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 0.5.0
Requires PHP: 7.4
License: GPL v2 or later

WordPress connector plugin for Minpaku Suite booking system.

== Description ==

This plugin provides WordPress integration for the Minpaku Suite booking system, including:

* Live availability calendar with pricing
* Interactive booking forms
* Property listings with embedded calendars
* Real-time quote calculations
* Japanese holiday support
* Responsive design

== Installation ==

1. Upload the plugin files to the /wp-content/plugins/wp-minpaku-connector directory
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Configure the plugin settings under Settings > Minpaku Connector

== Changelog ==

= 0.5.0 =
* NEW: Portal-style calendar with exact same styling and functionality as Minpaku Suite portal
* NEW: connector_calendar shortcode with full portal parity
* NEW: Modal calendar popup option for compact display
* NEW: Real-time pricing data synchronized with portal
* NEW: Click-to-book functionality redirecting to portal booking page
* NEW: Color-coded calendar (weekdays green, Saturdays blue, Sundays/holidays red)
* NEW: Price badges showing nightly rates on available days
* NEW: "貅螳､" (full) badges for booked dates
* IMPROVED: Enhanced responsive design matching portal styling
* IMPROVED: Japanese holiday detection and proper coloring
* IMPROVED: Portal calendar shortcode documentation and examples

