﻿=== WP Minpaku Connector ===
Contributors: minpaku-suite
Tags: booking, calendar, minpaku, vacation-rental
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 0.4.6
Requires PHP: 7.4
License: GPL v2 or later

WordPress connector plugin for Minpaku Suite booking system.

== Description ==

This plugin provides WordPress integration for the Minpaku Suite booking system, including:

* Live availability calendar with pricing
* Interactive booking forms
* Property listings with embedded calendars
* Real-time quote calculations
* Japanese holiday support
* Responsive design

== Installation ==

1. Upload the plugin files to the /wp-content/plugins/wp-minpaku-connector directory
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Configure the plugin settings under Settings > Minpaku Connector

== Changelog ==

= 0.4.6 =
* Fixed code output issue in property shortcode display
* Fixed pricing discrepancy between portal and connector calendars
* Added seasonal pricing and eve surcharge support matching portal side
* Fixed calendar click navigation to portal booking screen
* Added booking functionality with quote display and portal redirection
* Improved calendar interaction with checkin/checkout selection
* Enhanced CSS styling for quote display and booking buttons

